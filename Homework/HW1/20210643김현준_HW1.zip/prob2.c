int saturating_add(int x, int y) {

	//mask bit ���
	int w = sizeof(x) << 3;
	int mask = 1 << (w - 1);

	//�� ���
	int add = x + y;

	//x, y, add�� MSB ���
	int xmsb = x & mask;
	int ymsb = y & mask;
	int addmsb = add & mask;

	//positive, negative overflow Ȯ��
	int p_over = ~xmsb & ~ymsb & addmsb;
	int n_over = xmsb & ymsb & !addmsb;

	//TMAX, TMIN���� saturation
	p_over && (add = 2147483647);
	n_over && (add = -2147483648);

	return add;
}
